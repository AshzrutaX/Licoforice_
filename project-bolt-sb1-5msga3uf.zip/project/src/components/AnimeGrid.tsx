import React from 'react';
import { Anime } from '../types/anime';
import AnimeCard from './AnimeCard';

interface AnimeGridProps {
  anime: Anime[];
  title: string;
  onAnimeClick: (anime: Anime) => void;
  showAll?: boolean;
}

const AnimeGrid: React.FC<AnimeGridProps> = ({ anime, title, onAnimeClick, showAll = false }) => {
  const displayedAnime = showAll ? anime : anime.slice(0, 6);

  return (
    <section className="py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-2xl md:text-3xl font-bold text-white mb-6">{title}</h2>
        
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4 md:gap-6">
          {displayedAnime.map((item) => (
            <AnimeCard
              key={item.id}
              anime={item}
              onClick={onAnimeClick}
              size="medium"
            />
          ))}
        </div>

        {!showAll && anime.length > 6 && (
          <div className="text-center mt-8">
            <button className="bg-gray-800 hover:bg-gray-700 text-white px-6 py-3 rounded-lg font-semibold transition-colors border border-gray-700">
              View All
            </button>
          </div>
        )}
      </div>
    </section>
  );
};

export default AnimeGrid;
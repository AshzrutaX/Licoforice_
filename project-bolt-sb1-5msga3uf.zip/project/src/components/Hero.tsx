import React from 'react';
import { Play, Info, Star } from 'lucide-react';
import { Anime } from '../types/anime';

interface HeroProps {
  anime: Anime;
  onWatchNow: (anime: Anime) => void;
  onMoreInfo: (anime: Anime) => void;
}

const Hero: React.FC<HeroProps> = ({ anime, onWatchNow, onMoreInfo }) => {
  return (
    <div className="relative h-[70vh] min-h-[500px] overflow-hidden">
      {/* Background Image */}
      <div
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage: `url(${anime.banner})`,
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/50 to-transparent"></div>
        <div className="absolute inset-0 bg-gradient-to-t from-gray-900 via-transparent to-transparent"></div>
      </div>

      {/* Content */}
      <div className="relative h-full flex items-center">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
          <div className="max-w-2xl">
            <h1 className="text-4xl md:text-6xl font-bold text-white mb-4 leading-tight">
              {anime.title}
            </h1>
            
            <div className="flex items-center space-x-4 mb-6">
              <div className="flex items-center space-x-1">
                <Star className="w-5 h-5 text-yellow-400" fill="currentColor" />
                <span className="text-white font-semibold">{anime.rating}</span>
              </div>
              <span className="text-gray-300">{anime.year}</span>
              <span className="text-gray-300">{anime.episodes} Episodes</span>
              <span className="px-2 py-1 bg-red-600 text-white text-xs font-semibold rounded">
                {anime.status}
              </span>
            </div>

            <p className="text-lg text-gray-200 mb-8 leading-relaxed max-w-xl">
              {anime.description}
            </p>

            <div className="flex flex-col sm:flex-row gap-4">
              <button
                onClick={() => onWatchNow(anime)}
                className="flex items-center justify-center space-x-2 bg-red-600 hover:bg-red-700 text-white px-8 py-3 rounded-lg font-semibold transition-colors"
              >
                <Play className="w-5 h-5" fill="currentColor" />
                <span>Watch Now</span>
              </button>
              
              <button
                onClick={() => onMoreInfo(anime)}
                className="flex items-center justify-center space-x-2 bg-gray-800/80 hover:bg-gray-700/80 text-white px-8 py-3 rounded-lg font-semibold border border-gray-700 transition-colors backdrop-blur-sm"
              >
                <Info className="w-5 h-5" />
                <span>More Info</span>
              </button>
            </div>

            <div className="flex flex-wrap gap-2 mt-6">
              {anime.genres.map((genre) => (
                <span
                  key={genre}
                  className="px-3 py-1 bg-black/40 text-gray-300 text-sm rounded-full border border-gray-700"
                >
                  {genre}
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Hero;
import React, { useState, useRef } from 'react';
import { Play, Pause, Volume2, VolumeX, Maximize, SkipBack, SkipForward, Settings } from 'lucide-react';

interface VideoPlayerProps {
  title: string;
  episode: number;
  onNextEpisode?: () => void;
  onPrevEpisode?: () => void;
}

const VideoPlayer: React.FC<VideoPlayerProps> = ({ 
  title, 
  episode, 
  onNextEpisode, 
  onPrevEpisode 
}) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(1440); // 24 minutes in seconds
  const [showControls, setShowControls] = useState(true);
  const videoRef = useRef<HTMLDivElement>(null);

  const togglePlay = () => {
    setIsPlaying(!isPlaying);
  };

  const toggleMute = () => {
    setIsMuted(!isMuted);
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newTime = parseInt(e.target.value);
    setCurrentTime(newTime);
  };

  React.useEffect(() => {
    if (isPlaying) {
      const interval = setInterval(() => {
        setCurrentTime(prev => Math.min(prev + 1, duration));
      }, 1000);
      return () => clearInterval(interval);
    }
  }, [isPlaying, duration]);

  React.useEffect(() => {
    if (currentTime >= duration) {
      setIsPlaying(false);
      setCurrentTime(0);
    }
  }, [currentTime, duration]);

  return (
    <div className="bg-black rounded-lg overflow-hidden shadow-2xl">
      {/* Video Area */}
      <div
        ref={videoRef}
        className="relative aspect-video bg-gradient-to-br from-gray-900 to-black flex items-center justify-center cursor-pointer group"
        onMouseEnter={() => setShowControls(true)}
        onMouseLeave={() => setShowControls(false)}
        onClick={togglePlay}
      >
        {/* Placeholder Video Content */}
        <div className="absolute inset-0 bg-gradient-to-br from-red-900/20 to-blue-900/20">
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="text-center">
              <div className="w-24 h-24 bg-red-600 rounded-full flex items-center justify-center mb-4 mx-auto opacity-80">
                {isPlaying ? (
                  <Pause className="w-12 h-12 text-white" />
                ) : (
                  <Play className="w-12 h-12 text-white" fill="currentColor" />
                )}
              </div>
              <p className="text-white text-lg font-semibold">{title}</p>
              <p className="text-gray-300">Episode {episode}</p>
            </div>
          </div>
        </div>

        {/* Controls Overlay */}
        <div className={`absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/80 to-transparent p-6 transition-opacity duration-300 ${showControls ? 'opacity-100' : 'opacity-0'}`}>
          {/* Progress Bar */}
          <div className="mb-4">
            <input
              type="range"
              min="0"
              max={duration}
              value={currentTime}
              onChange={handleSeek}
              className="w-full h-1 bg-gray-600 rounded-lg appearance-none cursor-pointer slider"
            />
            <div className="flex justify-between text-xs text-gray-300 mt-1">
              <span>{formatTime(currentTime)}</span>
              <span>{formatTime(duration)}</span>
            </div>
          </div>

          {/* Controls */}
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              {/* Play/Pause */}
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  togglePlay();
                }}
                className="w-10 h-10 bg-red-600 hover:bg-red-700 rounded-full flex items-center justify-center transition-colors"
              >
                {isPlaying ? (
                  <Pause className="w-5 h-5 text-white" />
                ) : (
                  <Play className="w-5 h-5 text-white" fill="currentColor" />
                )}
              </button>

              {/* Previous Episode */}
              {onPrevEpisode && (
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onPrevEpisode();
                  }}
                  className="p-2 text-white hover:text-red-400 transition-colors"
                >
                  <SkipBack className="w-5 h-5" />
                </button>
              )}

              {/* Next Episode */}
              {onNextEpisode && (
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onNextEpisode();
                  }}
                  className="p-2 text-white hover:text-red-400 transition-colors"
                >
                  <SkipForward className="w-5 h-5" />
                </button>
              )}

              {/* Volume */}
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  toggleMute();
                }}
                className="p-2 text-white hover:text-red-400 transition-colors"
              >
                {isMuted ? (
                  <VolumeX className="w-5 h-5" />
                ) : (
                  <Volume2 className="w-5 h-5" />
                )}
              </button>

              {/* Episode Info */}
              <div className="text-white text-sm">
                <span className="font-semibold">EP {episode}</span>
              </div>
            </div>

            <div className="flex items-center space-x-2">
              {/* Settings */}
              <button
                onClick={(e) => e.stopPropagation()}
                className="p-2 text-white hover:text-red-400 transition-colors"
              >
                <Settings className="w-5 h-5" />
              </button>

              {/* Fullscreen */}
              <button
                onClick={(e) => e.stopPropagation()}
                className="p-2 text-white hover:text-red-400 transition-colors"
              >
                <Maximize className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default VideoPlayer;
import React from 'react';
import { Play, Star, Calendar, Clock } from 'lucide-react';
import { Anime } from '../types/anime';

interface AnimeCardProps {
  anime: Anime;
  onClick: (anime: Anime) => void;
  size?: 'small' | 'medium' | 'large';
}

const AnimeCard: React.FC<AnimeCardProps> = ({ anime, onClick, size = 'medium' }) => {
  const sizeClasses = {
    small: 'w-full max-w-[200px]',
    medium: 'w-full max-w-[250px]',
    large: 'w-full max-w-[300px]'
  };

  return (
    <div
      className={`${sizeClasses[size]} group cursor-pointer transition-all duration-300 hover:scale-105`}
      onClick={() => onClick(anime)}
    >
      <div className="relative overflow-hidden rounded-lg bg-gray-800 shadow-lg">
        {/* Poster Image */}
        <div className="aspect-[3/4] relative overflow-hidden">
          <img
            src={anime.poster}
            alt={anime.title}
            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
          />
          
          {/* Overlay */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
            <div className="absolute bottom-4 left-4 right-4">
              <div className="flex items-center justify-center mb-2">
                <div className="w-12 h-12 bg-red-600 rounded-full flex items-center justify-center hover:bg-red-700 transition-colors">
                  <Play className="w-6 h-6 text-white" fill="currentColor" />
                </div>
              </div>
            </div>
          </div>

          {/* Status Badge */}
          <div className="absolute top-2 right-2">
            <span className={`px-2 py-1 text-xs font-bold rounded ${
              anime.status === 'Ongoing' ? 'bg-green-600 text-white' :
              anime.status === 'Completed' ? 'bg-blue-600 text-white' :
              'bg-yellow-600 text-black'
            }`}>
              {anime.status}
            </span>
          </div>

          {/* Rating Badge */}
          <div className="absolute top-2 left-2">
            <div className="flex items-center space-x-1 bg-black/70 px-2 py-1 rounded">
              <Star className="w-3 h-3 text-yellow-400" fill="currentColor" />
              <span className="text-white text-xs font-semibold">{anime.rating}</span>
            </div>
          </div>
        </div>

        {/* Content */}
        <div className="p-4">
          <h3 className="text-white font-semibold text-sm mb-2 line-clamp-2 group-hover:text-red-400 transition-colors">
            {anime.title}
          </h3>
          
          <div className="flex items-center justify-between text-xs text-gray-400 mb-2">
            <div className="flex items-center space-x-1">
              <Calendar className="w-3 h-3" />
              <span>{anime.year}</span>
            </div>
            <div className="flex items-center space-x-1">
              <Clock className="w-3 h-3" />
              <span>{anime.duration}</span>
            </div>
          </div>

          <div className="flex flex-wrap gap-1 mb-2">
            {anime.genres.slice(0, 2).map((genre) => (
              <span
                key={genre}
                className="px-2 py-1 bg-gray-700 text-gray-300 text-xs rounded"
              >
                {genre}
              </span>
            ))}
            {anime.genres.length > 2 && (
              <span className="px-2 py-1 bg-gray-700 text-gray-300 text-xs rounded">
                +{anime.genres.length - 2}
              </span>
            )}
          </div>

          <p className="text-gray-400 text-xs line-clamp-2">
            {anime.description}
          </p>
        </div>
      </div>
    </div>
  );
};

export default AnimeCard;
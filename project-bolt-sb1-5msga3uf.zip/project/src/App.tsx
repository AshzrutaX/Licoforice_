import React, { useState } from 'react';
import { Anime } from './types/anime';
import { mockAnime } from './data/mockData';
import Header from './components/Header';
import Home from './pages/Home';
import Search from './pages/Search';
import AnimeDetail from './pages/AnimeDetail';

type Page = 'home' | 'search' | 'anime';

function App() {
  const [currentPage, setCurrentPage] = useState<Page>('home');
  const [selectedAnime, setSelectedAnime] = useState<Anime | null>(null);
  const [searchQuery, setSearchQuery] = useState('');

  const handleSearch = (query: string) => {
    setSearchQuery(query);
    setCurrentPage('search');
  };

  const handleAnimeClick = (anime: Anime) => {
    setSelectedAnime(anime);
    setCurrentPage('anime');
  };

  const handleWatchNow = (anime: Anime) => {
    setSelectedAnime(anime);
    setCurrentPage('anime');
  };

  const handleNavigate = (page: 'home' | 'search') => {
    setCurrentPage(page);
    if (page === 'home') {
      setSearchQuery('');
    }
  };

  const handleBack = () => {
    setCurrentPage('home');
    setSelectedAnime(null);
  };

  return (
    <div className="min-h-screen bg-gray-900">
      <Header
        onSearch={handleSearch}
        currentPage={currentPage}
        onNavigate={handleNavigate}
      />

      {currentPage === 'home' && (
        <Home
          anime={mockAnime}
          onAnimeClick={handleAnimeClick}
          onWatchNow={handleWatchNow}
        />
      )}

      {currentPage === 'search' && (
        <Search
          anime={mockAnime}
          searchQuery={searchQuery}
          onAnimeClick={handleAnimeClick}
        />
      )}

      {currentPage === 'anime' && selectedAnime && (
        <AnimeDetail
          anime={selectedAnime}
          onBack={handleBack}
          onWatchNow={handleWatchNow}
        />
      )}
    </div>
  );
}

export default App;
import React, { useState } from 'react';
import { ArrowLeft, Play, Plus, Share2, Star, Calendar, Clock, Users, Building } from 'lucide-react';
import { Anime } from '../types/anime';
import VideoPlayer from '../components/VideoPlayer';
import { mockEpisodes } from '../data/mockData';

interface AnimeDetailProps {
  anime: Anime;
  onBack: () => void;
  onWatchNow: (anime: Anime) => void;
}

const AnimeDetail: React.FC<AnimeDetailProps> = ({ anime, onBack, onWatchNow }) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'episodes' | 'reviews'>('overview');
  const [showPlayer, setShowPlayer] = useState(false);
  const [currentEpisode, setCurrentEpisode] = useState(1);

  const episodes = mockEpisodes[anime.id] || [];

  const handleWatchEpisode = (episodeNumber: number) => {
    setCurrentEpisode(episodeNumber);
    setShowPlayer(true);
  };

  return (
    <div className="min-h-screen bg-gray-900">
      {/* Header */}
      <div className="sticky top-16 bg-gray-900/95 backdrop-blur-sm border-b border-gray-800 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <button
            onClick={onBack}
            className="flex items-center space-x-2 text-gray-400 hover:text-white transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            <span>Back</span>
          </button>
        </div>
      </div>

      {/* Video Player */}
      {showPlayer && (
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <VideoPlayer
            title={anime.title}
            episode={currentEpisode}
            onNextEpisode={() => setCurrentEpisode(prev => prev + 1)}
            onPrevEpisode={() => setCurrentEpisode(prev => Math.max(1, prev - 1))}
          />
        </div>
      )}

      {/* Hero Section */}
      <div className="relative">
        <div
          className="h-[50vh] bg-cover bg-center bg-no-repeat"
          style={{
            backgroundImage: `url(${anime.banner})`,
          }}
        >
          <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/50 to-transparent"></div>
          <div className="absolute inset-0 bg-gradient-to-t from-gray-900 via-transparent to-transparent"></div>
        </div>

        <div className="absolute bottom-0 left-0 right-0 p-8">
          <div className="max-w-7xl mx-auto">
            <div className="flex flex-col md:flex-row gap-8">
              {/* Poster */}
              <div className="flex-shrink-0">
                <img
                  src={anime.poster}
                  alt={anime.title}
                  className="w-48 h-72 object-cover rounded-lg shadow-2xl"
                />
              </div>

              {/* Info */}
              <div className="flex-1">
                <h1 className="text-4xl md:text-6xl font-bold text-white mb-4">
                  {anime.title}
                </h1>

                <div className="flex flex-wrap items-center gap-4 mb-6">
                  <div className="flex items-center space-x-1">
                    <Star className="w-5 h-5 text-yellow-400" fill="currentColor" />
                    <span className="text-white font-semibold">{anime.rating}</span>
                  </div>
                  <span className="text-gray-300">{anime.year}</span>
                  <span className="text-gray-300">{anime.episodes} Episodes</span>
                  <span className={`px-2 py-1 text-xs font-semibold rounded ${
                    anime.status === 'Ongoing' ? 'bg-green-600 text-white' :
                    anime.status === 'Completed' ? 'bg-blue-600 text-white' :
                    'bg-yellow-600 text-black'
                  }`}>
                    {anime.status}
                  </span>
                </div>

                <p className="text-lg text-gray-200 mb-6 max-w-3xl">
                  {anime.description}
                </p>

                <div className="flex flex-wrap gap-4">
                  <button
                    onClick={() => onWatchNow(anime)}
                    className="flex items-center space-x-2 bg-red-600 hover:bg-red-700 text-white px-6 py-3 rounded-lg font-semibold transition-colors"
                  >
                    <Play className="w-5 h-5" fill="currentColor" />
                    <span>Watch Now</span>
                  </button>
                  
                  <button className="flex items-center space-x-2 bg-gray-800 hover:bg-gray-700 text-white px-6 py-3 rounded-lg font-semibold transition-colors">
                    <Plus className="w-5 h-5" />
                    <span>Add to List</span>
                  </button>
                  
                  <button className="flex items-center space-x-2 bg-gray-800 hover:bg-gray-700 text-white px-6 py-3 rounded-lg font-semibold transition-colors">
                    <Share2 className="w-5 h-5" />
                    <span>Share</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Tabs */}
        <div className="border-b border-gray-800 mb-8">
          <nav className="flex space-x-8">
            {['overview', 'episodes', 'reviews'].map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab as any)}
                className={`py-4 px-1 border-b-2 font-medium text-sm capitalize transition-colors ${
                  activeTab === tab
                    ? 'border-red-500 text-red-500'
                    : 'border-transparent text-gray-400 hover:text-gray-300'
                }`}
              >
                {tab}
              </button>
            ))}
          </nav>
        </div>

        {/* Tab Content */}
        {activeTab === 'overview' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2">
              <h3 className="text-xl font-semibold text-white mb-4">Synopsis</h3>
              <p className="text-gray-300 leading-relaxed mb-6">
                {anime.description}
              </p>

              <div className="flex flex-wrap gap-2">
                {anime.genres.map((genre) => (
                  <span
                    key={genre}
                    className="px-3 py-1 bg-gray-800 text-gray-300 rounded-full text-sm"
                  >
                    {genre}
                  </span>
                ))}
              </div>
            </div>

            <div className="space-y-6">
              <div className="bg-gray-800 rounded-lg p-6">
                <h3 className="text-lg font-semibold text-white mb-4">Details</h3>
                <div className="space-y-3">
                  <div className="flex items-center space-x-3">
                    <Calendar className="w-5 h-5 text-gray-400" />
                    <div>
                      <span className="text-gray-400">Year: </span>
                      <span className="text-white">{anime.year}</span>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3">
                    <Clock className="w-5 h-5 text-gray-400" />
                    <div>
                      <span className="text-gray-400">Duration: </span>
                      <span className="text-white">{anime.duration}</span>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3">
                    <Building className="w-5 h-5 text-gray-400" />
                    <div>
                      <span className="text-gray-400">Studio: </span>
                      <span className="text-white">{anime.studio}</span>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3">
                    <Users className="w-5 h-5 text-gray-400" />
                    <div>
                      <span className="text-gray-400">Episodes: </span>
                      <span className="text-white">{anime.episodes}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'episodes' && (
          <div>
            <h3 className="text-xl font-semibold text-white mb-6">Episodes</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {Array.from({ length: Math.min(anime.episodes, 12) }, (_, i) => i + 1).map((episodeNum) => (
                <div
                  key={episodeNum}
                  className="bg-gray-800 rounded-lg p-4 hover:bg-gray-700 transition-colors cursor-pointer"
                  onClick={() => handleWatchEpisode(episodeNum)}
                >
                  <div className="flex items-center space-x-4">
                    <div className="w-16 h-12 bg-gray-700 rounded overflow-hidden flex-shrink-0">
                      <img
                        src={anime.poster}
                        alt={`Episode ${episodeNum}`}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="flex-1">
                      <h4 className="text-white font-medium">Episode {episodeNum}</h4>
                      <p className="text-gray-400 text-sm">24 min</p>
                    </div>
                    <Play className="w-5 h-5 text-red-500" />
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'reviews' && (
          <div>
            <h3 className="text-xl font-semibold text-white mb-6">Reviews</h3>
            <div className="space-y-6">
              {[1, 2, 3].map((review) => (
                <div key={review} className="bg-gray-800 rounded-lg p-6">
                  <div className="flex items-center space-x-4 mb-4">
                    <div className="w-10 h-10 bg-red-600 rounded-full flex items-center justify-center">
                      <span className="text-white font-semibold">U</span>
                    </div>
                    <div>
                      <h4 className="text-white font-medium">User{review}</h4>
                      <div className="flex items-center space-x-1">
                        {[...Array(5)].map((_, i) => (
                          <Star
                            key={i}
                            className={`w-4 h-4 ${i < 4 ? 'text-yellow-400' : 'text-gray-600'}`}
                            fill="currentColor"
                          />
                        ))}
                      </div>
                    </div>
                  </div>
                  <p className="text-gray-300">
                    This anime is absolutely fantastic! The animation quality is top-notch and the story keeps you engaged throughout every episode.
                  </p>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default AnimeDetail;
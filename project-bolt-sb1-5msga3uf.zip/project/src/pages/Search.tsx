import React, { useState, useMemo } from 'react';
import { Filter, Grid, List } from 'lucide-react';
import { Anime } from '../types/anime';
import AnimeCard from '../components/AnimeCard';

interface SearchProps {
  anime: Anime[];
  searchQuery: string;
  onAnimeClick: (anime: Anime) => void;
}

const Search: React.FC<SearchProps> = ({ anime, searchQuery, onAnimeClick }) => {
  const [selectedGenre, setSelectedGenre] = useState<string>('');
  const [selectedStatus, setSelectedStatus] = useState<string>('');
  const [selectedYear, setSelectedYear] = useState<string>('');
  const [sortBy, setSortBy] = useState<string>('title');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');

  // Get unique values for filters
  const genres = useMemo(() => {
    const allGenres = anime.flatMap(a => a.genres);
    return Array.from(new Set(allGenres)).sort();
  }, [anime]);

  const years = useMemo(() => {
    const allYears = anime.map(a => a.year.toString());
    return Array.from(new Set(allYears)).sort((a, b) => parseInt(b) - parseInt(a));
  }, [anime]);

  const filteredAnime = useMemo(() => {
    let filtered = anime;

    // Text search
    if (searchQuery) {
      filtered = filtered.filter(a =>
        a.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        a.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        a.genres.some(g => g.toLowerCase().includes(searchQuery.toLowerCase()))
      );
    }

    // Genre filter
    if (selectedGenre) {
      filtered = filtered.filter(a => a.genres.includes(selectedGenre));
    }

    // Status filter
    if (selectedStatus) {
      filtered = filtered.filter(a => a.status === selectedStatus);
    }

    // Year filter
    if (selectedYear) {
      filtered = filtered.filter(a => a.year.toString() === selectedYear);
    }

    // Sort
    filtered = [...filtered].sort((a, b) => {
      switch (sortBy) {
        case 'title':
          return a.title.localeCompare(b.title);
        case 'year':
          return b.year - a.year;
        case 'rating':
          return b.rating - a.rating;
        case 'episodes':
          return b.episodes - a.episodes;
        default:
          return 0;
      }
    });

    return filtered;
  }, [anime, searchQuery, selectedGenre, selectedStatus, selectedYear, sortBy]);

  return (
    <div className="min-h-screen bg-gray-900 pt-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-white mb-2">
            {searchQuery ? `Search Results for "${searchQuery}"` : 'Browse Anime'}
          </h1>
          <p className="text-gray-400">
            {filteredAnime.length} anime found
          </p>
        </div>

        {/* Filters */}
        <div className="bg-gray-800 rounded-lg p-6 mb-8">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-white flex items-center">
              <Filter className="w-5 h-5 mr-2" />
              Filters
            </h2>
            <div className="flex items-center space-x-2">
              <button
                onClick={() => setViewMode('grid')}
                className={`p-2 rounded ${viewMode === 'grid' ? 'bg-red-600 text-white' : 'text-gray-400 hover:text-white'}`}
              >
                <Grid className="w-4 h-4" />
              </button>
              <button
                onClick={() => setViewMode('list')}
                className={`p-2 rounded ${viewMode === 'list' ? 'bg-red-600 text-white' : 'text-gray-400 hover:text-white'}`}
              >
                <List className="w-4 h-4" />
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">Genre</label>
              <select
                value={selectedGenre}
                onChange={(e) => setSelectedGenre(e.target.value)}
                className="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-red-500"
              >
                <option value="">All Genres</option>
                {genres.map(genre => (
                  <option key={genre} value={genre}>{genre}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">Status</label>
              <select
                value={selectedStatus}
                onChange={(e) => setSelectedStatus(e.target.value)}
                className="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-red-500"
              >
                <option value="">All Status</option>
                <option value="Ongoing">Ongoing</option>
                <option value="Completed">Completed</option>
                <option value="Upcoming">Upcoming</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">Year</label>
              <select
                value={selectedYear}
                onChange={(e) => setSelectedYear(e.target.value)}
                className="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-red-500"
              >
                <option value="">All Years</option>
                {years.map(year => (
                  <option key={year} value={year}>{year}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">Sort By</label>
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                className="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-red-500"
              >
                <option value="title">Title</option>
                <option value="year">Year</option>
                <option value="rating">Rating</option>
                <option value="episodes">Episodes</option>
              </select>
            </div>
          </div>

          <div className="mt-4 flex flex-wrap gap-2">
            {selectedGenre && (
              <span className="px-3 py-1 bg-red-600 text-white text-sm rounded-full flex items-center">
                Genre: {selectedGenre}
                <button
                  onClick={() => setSelectedGenre('')}
                  className="ml-2 text-red-200 hover:text-white"
                >
                  ×
                </button>
              </span>
            )}
            {selectedStatus && (
              <span className="px-3 py-1 bg-red-600 text-white text-sm rounded-full flex items-center">
                Status: {selectedStatus}
                <button
                  onClick={() => setSelectedStatus('')}
                  className="ml-2 text-red-200 hover:text-white"
                >
                  ×
                </button>
              </span>
            )}
            {selectedYear && (
              <span className="px-3 py-1 bg-red-600 text-white text-sm rounded-full flex items-center">
                Year: {selectedYear}
                <button
                  onClick={() => setSelectedYear('')}
                  className="ml-2 text-red-200 hover:text-white"
                >
                  ×
                </button>
              </span>
            )}
          </div>
        </div>

        {/* Results */}
        {filteredAnime.length > 0 ? (
          <div className={`grid gap-6 pb-16 ${
            viewMode === 'grid' 
              ? 'grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6' 
              : 'grid-cols-1 md:grid-cols-2 lg:grid-cols-3'
          }`}>
            {filteredAnime.map((item) => (
              <AnimeCard
                key={item.id}
                anime={item}
                onClick={onAnimeClick}
                size={viewMode === 'list' ? 'large' : 'medium'}
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-16">
            <p className="text-gray-400 text-lg">No anime found matching your criteria</p>
            <p className="text-gray-500 text-sm mt-2">Try adjusting your filters or search query</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default Search;
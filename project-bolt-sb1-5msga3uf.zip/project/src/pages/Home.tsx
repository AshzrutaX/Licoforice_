import React from 'react';
import { Anime } from '../types/anime';
import Hero from '../components/Hero';
import AnimeGrid from '../components/AnimeGrid';

interface HomeProps {
  anime: Anime[];
  onAnimeClick: (anime: Anime) => void;
  onWatchNow: (anime: Anime) => void;
}

const Home: React.FC<HomeProps> = ({ anime, onAnimeClick, onWatchNow }) => {
  const featuredAnime = anime[0];
  const popularAnime = anime.slice(1, 7);
  const newReleases = anime.slice(2, 8);
  const trending = anime.slice(0, 6);

  return (
    <div className="min-h-screen bg-gray-900">
      {/* Hero Section */}
      <Hero
        anime={featuredAnime}
        onWatchNow={onWatchNow}
        onMoreInfo={onAnimeClick}
      />

      {/* Content Sections */}
      <div className="space-y-8 pb-16">
        <AnimeGrid
          anime={trending}
          title="Trending Now"
          onAnimeClick={onAnimeClick}
        />
        
        <AnimeGrid
          anime={popularAnime}
          title="Popular This Week"
          onAnimeClick={onAnimeClick}
        />
        
        <AnimeGrid
          anime={newReleases}
          title="New Releases"
          onAnimeClick={onAnimeClick}
        />
      </div>
    </div>
  );
};

export default Home;